export default function App() {
  return (
    <main className="bg-white text-gray-800 font-sans">
      <header className="bg-blue-950 text-white p-6 shadow">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">BIOFARMED</h1>
          <p className="text-sm">дочерняя компания HEILER</p>
        </div>
      </header>

      <section className="bg-blue-100 py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-4">Современные решения в офтальмологии</h2>
          <p className="text-lg text-gray-700">Инновационные препараты для здоровья глаз. Качество. Наука. Забота.</p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h3 className="text-3xl font-bold mb-6 text-center">Наша продукция</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="rounded-xl shadow p-4">
              <img src="/lumixa.jpg" alt="Lumixa" className="rounded mb-2" />
              <h4 className="text-xl font-semibold">Lumixa</h4>
              <p className="text-sm">Гиалуроновая кислота, кроцин, защита от синего света</p>
            </div>
            <div className="rounded-xl shadow p-4">
              <img src="/visneurox.jpg" alt="Visneurox" className="rounded mb-2" />
              <h4 className="text-xl font-semibold">Visneurox LF</h4>
              <p className="text-sm">Антиоксидантная защита зрительного нерва</p>
            </div>
            <div className="rounded-xl shadow p-4">
              <img src="/droptherapeutic.jpg" alt="Drop Therapeutic" className="rounded mb-2" />
              <h4 className="text-xl font-semibold">Drop Therapeutic</h4>
              <p className="text-sm">Естественный кросс-линкинг роговицы</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h3 className="text-3xl font-bold mb-6 text-center">Научный подход</h3>
          <p className="text-center text-gray-700 mb-4">Мы сотрудничаем с ведущими офтальмологами и клиниками. Каждое средство проходит доклинические и клинические испытания.</p>
          <div className="flex justify-center">
            <img src="/science.jpg" alt="Science" className="rounded-xl w-full max-w-xl" />
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h3 className="text-3xl font-bold mb-6 text-center">Связаться с нами</h3>
          <form className="max-w-xl mx-auto grid gap-4">
            <input type="text" placeholder="Ваше имя" className="border rounded p-3" />
            <input type="email" placeholder="Email" className="border rounded p-3" />
            <textarea placeholder="Ваше сообщение" rows="4" className="border rounded p-3"></textarea>
            <button type="submit" className="bg-blue-800 text-white py-3 rounded hover:bg-blue-900">Отправить</button>
          </form>
        </div>
      </section>

      <footer className="bg-blue-950 text-white text-center py-4 text-sm">
        <p>&copy; 2025 BIOFARMED. Все права защищены. | RU | KZ | EN</p>
      </footer>
    </main>
  );
}
